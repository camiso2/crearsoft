<!-- The Modal -->
<div class="modal" id="videos">
    <div class="modal-dialog modal-lg" style="background-color: transparent; border:0">
        <div class="modal-content">
            <!-- Modal Header -->

            <!-- Modal body -->
            <div class="modal-body" style="background-color: transparent; border:0">
                <div class="ratio ratio-16x9">
                    <iframe id="src_video" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>
                    </iframe>
                </div>


                <div class="container">
                <div class="section-heading" style="margin-top:15px">
                    <h2>Proyecto <em id="title"></em><br><span class="technologies-modal" id="technologies" style="width: 98%;white-space: nowrap;text-overflow: ellipsis;overflow: hidden;"></span></h2>
                    <br>

                    <p id="description-project"></p>
                    <a rel="nofollow" href="/cv/jaiver.pdf" target="_blank"><button class="btn btn-success"
                            style="font-size: 22px; font-weight:800;border:0;margin-top:20px"><i
                                class="fa fa-file-pdf-o"></i>&nbsp;&nbsp;Descargar CV </button></a>
             
                    
                </div>
                </div>

            </div>
            <!-- Modal footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" id='close_modal'> <i class="fa fa-close"></i>&nbsp;&nbsp;
                    CERRAR</button>
            </div>

            <script>
                $('#close_modal').click(function() {
                    $("#videos").modal('hide');
                    $('body').removeClass('modal-open');
                    $('.modal-backdrop').remove();
                    $("#src_video").attr('src', '');
                });
            </script>


        </div>
    </div>
</div>



