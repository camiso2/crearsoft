<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>


<?php if(session('error')): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'ERROR',
            text: '<?php echo e(session('error')); ?>',
            showCancelButton: true,
            confirmButtonText: "Intentarlo De Nuevo.",
            cancelButtonText: "Cancelar",
        }).then(resultado => {
        if (resultado.value) {
            
            setTimeout(function(){
                location.hash = "#contact" ;
            }, 500);
        } else{
            console.log("Cierra Dialogo !");
        }
    });
    </script>
    <?php endif; ?>
    <?php if(session('success')): ?>
    <script>
    Swal.fire({
        icon: 'success',
        title: 'INFORMACIÓN',
        text: '<?php echo e(session('success')); ?>',
        confirmButtonText: "Gracias Por Su Mensaje.",
    })
    </script>
    <?php endif; ?>